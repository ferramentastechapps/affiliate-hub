globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/giM4NfgWFpCUdac2OUJVZ/_buildManifest.js",
    "static/giM4NfgWFpCUdac2OUJVZ/_ssgManifest.js",
    "static/giM4NfgWFpCUdac2OUJVZ/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0-4oo_oi06i0r.js",
    "static/chunks/0gqlnx1g3u12j.js",
    "static/chunks/0.~2ky53fo~10.js",
    "static/chunks/15pwyws4by~es.js",
    "static/chunks/0h~817hl6rlpb.js",
    "static/chunks/turbopack-11zk4ylsh9i5e.js"
  ]
};
