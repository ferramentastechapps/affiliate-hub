globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/m_3-PogktEcTETU7vQp5l/_buildManifest.js",
    "static/m_3-PogktEcTETU7vQp5l/_ssgManifest.js",
    "static/m_3-PogktEcTETU7vQp5l/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0-4oo_oi06i0r.js",
    "static/chunks/0gqlnx1g3u12j.js",
    "static/chunks/0.~2ky53fo~10.js",
    "static/chunks/15pwyws4by~es.js",
    "static/chunks/0h~817hl6rlpb.js",
    "static/chunks/turbopack-11zk4ylsh9i5e.js"
  ]
};
