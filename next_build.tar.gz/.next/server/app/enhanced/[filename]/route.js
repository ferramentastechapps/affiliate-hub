var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/enhanced/[filename]/route.js")
R.c("server/chunks/[root-of-the-server]__0yhr84q._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_enhanced_[filename]_route_actions_0reys~s.js")
R.m(47491)
module.exports=R.m(47491).exports
