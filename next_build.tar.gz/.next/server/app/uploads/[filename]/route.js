var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/uploads/[filename]/route.js")
R.c("server/chunks/[root-of-the-server]__0.62aow._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_uploads_[filename]_route_actions_0s8_9uc.js")
R.m(36146)
module.exports=R.m(36146).exports
