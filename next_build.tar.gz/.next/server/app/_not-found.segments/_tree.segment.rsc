:HL["/_next/static/chunks/0v6qfd9un4bnq.css","style"]
:HL["/_next/static/chunks/0xl24d~w6a-uz.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":20,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"m_3-PogktEcTETU7vQp5l"}
