:HL["/_next/static/chunks/0v6qfd9un4bnq.css","style"]
:HL["/_next/static/chunks/0c-c8opixz81m.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":20,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":0,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":0,"slots":null}}}}},"staleTime":300,"buildId":"dSKJU8O3nlBVzcM9iiqG9"}
