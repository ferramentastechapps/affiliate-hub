1:"$Sreact.fragment"
2:I[39756,["/_next/static/chunks/0rl86lnyn.6w2.js","/_next/static/chunks/0iiip_n.92jov.js","/_next/static/chunks/02doqmwt_i1bk.js","/_next/static/chunks/06._p59qxe-5..js","/_next/static/chunks/0alzscbwojz5y.js","/_next/static/chunks/09t2isllljna7.js"],"default"]
3:I[37457,["/_next/static/chunks/0rl86lnyn.6w2.js","/_next/static/chunks/0iiip_n.92jov.js","/_next/static/chunks/02doqmwt_i1bk.js","/_next/static/chunks/06._p59qxe-5..js","/_next/static/chunks/0alzscbwojz5y.js","/_next/static/chunks/09t2isllljna7.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"dSKJU8O3nlBVzcM9iiqG9"}
