var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/track/click/route.js")
R.c("server/chunks/[root-of-the-server]__0xi056d._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_track_click_route_actions_03hlavb.js")
R.m(72337)
module.exports=R.m(72337).exports
