var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/push/history/route.js")
R.c("server/chunks/[root-of-the-server]__0e_~7gh._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_push_history_route_actions_00o5_cm.js")
R.m(32663)
module.exports=R.m(32663).exports
