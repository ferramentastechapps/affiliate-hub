var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/push/send/route.js")
R.c("server/chunks/[root-of-the-server]__12xzgyv._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/[root-of-the-server]__0w~ehrn._.js")
R.c("server/chunks/_next-internal_server_app_api_push_send_route_actions_0lj594y.js")
R.m(29005)
module.exports=R.m(29005).exports
