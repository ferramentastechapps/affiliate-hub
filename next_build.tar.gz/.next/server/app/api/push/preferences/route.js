var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/push/preferences/route.js")
R.c("server/chunks/[root-of-the-server]__0cv.1sq._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_push_preferences_route_actions_0m~a.uq.js")
R.m(25778)
module.exports=R.m(25778).exports
