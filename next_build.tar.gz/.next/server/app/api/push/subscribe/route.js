var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/push/subscribe/route.js")
R.c("server/chunks/[root-of-the-server]__0rp88.w._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/node_modules_next_124cnn1._.js")
R.c("server/chunks/_next-internal_server_app_api_push_subscribe_route_actions_13exz7v.js")
R.m(63563)
module.exports=R.m(63563).exports
