var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/webhook/products/reject/route.js")
R.c("server/chunks/[root-of-the-server]__0bv7ij4._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_webhook_products_reject_route_actions_0mca7v7.js")
R.m(35733)
module.exports=R.m(35733).exports
