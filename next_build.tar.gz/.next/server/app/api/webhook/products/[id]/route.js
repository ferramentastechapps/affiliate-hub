var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/webhook/products/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__0jc2jpz._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_webhook_products_[id]_route_actions_13ay8-j.js")
R.m(31050)
module.exports=R.m(31050).exports
