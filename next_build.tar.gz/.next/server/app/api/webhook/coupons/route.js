var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/webhook/coupons/route.js")
R.c("server/chunks/[root-of-the-server]__0v6_7.q._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_webhook_coupons_route_actions_0grhtpf.js")
R.m(11362)
module.exports=R.m(11362).exports
