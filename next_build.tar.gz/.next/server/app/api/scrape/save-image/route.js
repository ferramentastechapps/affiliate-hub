var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/scrape/save-image/route.js")
R.c("server/chunks/[root-of-the-server]__09e3.a_._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_scrape_save-image_route_actions_0xmbnrd.js")
R.m(39013)
module.exports=R.m(39013).exports
