var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/scrape/route.js")
R.c("server/chunks/src_lib_scraper_ts_13yvcv_._.js")
R.c("server/chunks/[root-of-the-server]__0j.lmv-._.js")
R.c("server/chunks/node_modules_next_124cnn1._.js")
R.c("server/chunks/[root-of-the-server]__13ymcc.._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_scrape_route_actions_07b7qwi.js")
R.m(38477)
module.exports=R.m(38477).exports
