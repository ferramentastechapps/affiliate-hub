var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/products/[id]/price-history/route.js")
R.c("server/chunks/[root-of-the-server]__10uymi3._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_products_[id]_price-history_route_actions_0-krmdf.js")
R.m(75412)
module.exports=R.m(75412).exports
