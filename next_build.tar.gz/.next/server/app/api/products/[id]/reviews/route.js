var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/products/[id]/reviews/route.js")
R.c("server/chunks/[root-of-the-server]__0n2ierq._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_products_[id]_reviews_route_actions_00-gv0u.js")
R.m(9195)
module.exports=R.m(9195).exports
