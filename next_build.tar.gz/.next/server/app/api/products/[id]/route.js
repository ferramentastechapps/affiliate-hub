var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/products/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__034pjoq._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_0-43kv0.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/node_modules_next_124cnn1._.js")
R.c("server/chunks/_next-internal_server_app_api_products_[id]_route_actions_0gjxx5m.js")
R.m(48527)
module.exports=R.m(48527).exports
