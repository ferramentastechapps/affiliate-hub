var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/products/[id]/vote/route.js")
R.c("server/chunks/[root-of-the-server]__07u8spm._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_products_[id]_vote_route_actions_0a0p5yj.js")
R.m(49557)
module.exports=R.m(49557).exports
