var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/products/[id]/reprocess/route.js")
R.c("server/chunks/[root-of-the-server]__0yk7pna._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/node_modules_next_124cnn1._.js")
R.c("server/chunks/_next-internal_server_app_api_products_[id]_reprocess_route_actions_0uvpytd.js")
R.m(19369)
module.exports=R.m(19369).exports
