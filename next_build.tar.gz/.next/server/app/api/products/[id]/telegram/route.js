var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/products/[id]/telegram/route.js")
R.c("server/chunks/[root-of-the-server]__0u4tme4._.js")
R.c("server/chunks/src_lib_affiliate_ts_10.vmvb._.js")
R.c("server/chunks/[root-of-the-server]__13ymcc.._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_products_[id]_telegram_route_actions_0l-yq-k.js")
R.m(41206)
module.exports=R.m(41206).exports
