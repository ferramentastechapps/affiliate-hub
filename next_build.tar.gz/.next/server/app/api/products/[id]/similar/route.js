var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/products/[id]/similar/route.js")
R.c("server/chunks/[root-of-the-server]__0mdz~0~._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/_next-internal_server_app_api_products_[id]_similar_route_actions_0hhf1q_.js")
R.m(53419)
module.exports=R.m(53419).exports
