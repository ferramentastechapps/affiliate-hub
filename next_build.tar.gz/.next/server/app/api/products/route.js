var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/products/route.js")
R.c("server/chunks/[root-of-the-server]__13u~e6c._.js")
R.c("server/chunks/[root-of-the-server]__0j8-xkl._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_114bsdm.js")
R.c("server/chunks/_next-internal_server_app_api_products_route_actions_0qlulka.js")
R.m(47974)
module.exports=R.m(47974).exports
