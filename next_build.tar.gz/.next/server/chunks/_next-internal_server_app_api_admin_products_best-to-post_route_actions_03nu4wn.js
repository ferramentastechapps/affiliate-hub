module.exports=[77255,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_products_best-to-post_route_actions_03nu4wn.js.map