module.exports=[27605,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_ai-studio_captions_route_actions_0qic5g6.js.map