module.exports=[13227,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_products_%5Bid%5D_comments_route_actions_0-9zwsh.js.map