module.exports=[2677,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_products_%5Bid%5D_alert_route_actions_12m2n2t.js.map