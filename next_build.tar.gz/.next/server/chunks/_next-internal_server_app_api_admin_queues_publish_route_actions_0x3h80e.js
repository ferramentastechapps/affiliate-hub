module.exports=[36818,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_queues_publish_route_actions_0x3h80e.js.map