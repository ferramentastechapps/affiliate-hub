module.exports=[12226,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_queues_remove_route_actions_0.jamf~.js.map