module.exports=[355,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_bot_trigger_route_actions_12go709.js.map