module.exports=[78028,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_webhook_products_approve_route_actions_0_j5ins.js.map