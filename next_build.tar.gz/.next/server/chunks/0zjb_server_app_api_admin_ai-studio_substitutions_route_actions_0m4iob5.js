module.exports=[27200,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_admin_ai-studio_substitutions_route_actions_0m4iob5.js.map