module.exports=[25987,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_config_test_whatsapp_route_actions_0eol9bs.js.map