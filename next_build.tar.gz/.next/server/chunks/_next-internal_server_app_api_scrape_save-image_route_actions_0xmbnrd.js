module.exports=[79832,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_scrape_save-image_route_actions_0xmbnrd.js.map