module.exports=[37018,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_analytics_tokens_route_actions_0vx68az.js.map