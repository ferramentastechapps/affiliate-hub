module.exports=[48808,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_subcategories_route_actions_0s4lgnm.js.map