module.exports=[69711,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_products_%5Bid%5D_images_route_actions_0foj65i.js.map