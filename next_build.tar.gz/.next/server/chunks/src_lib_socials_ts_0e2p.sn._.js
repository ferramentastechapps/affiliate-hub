module.exports=[10278,e=>{"use strict";var a=e.i(98043),o=e.i(27837);function i(e){if(null==e)return"";let a="string"==typeof e?parseFloat(e):e;return isNaN(a)?String(e):a.toFixed(2).replace(".",",")}async function r(e,r){let s=process.env.TELEGRAM_PROMO_GROUP_ID,t=await a.prisma.systemConfig.findUnique({where:{key:"whatsapp_api_url"}}),l=await a.prisma.systemConfig.findUnique({where:{key:"whatsapp_api_token"}}),p=e.platform.charAt(0).toUpperCase()+e.platform.slice(1);"mercadolivre"===e.platform?p="Mercado Livre":"magalu"===e.platform?p="Magazine Luiza":"aliexpress"===e.platform&&(p="AliExpress");let c="";if(e.minPurchaseValue||e.maxDiscountValue||e.applicableCategories){let a=[];e.minPurchaseValue&&a.push(`Acima de R$ ${i(e.minPurchaseValue)}`),e.maxDiscountValue&&a.push(`Limite de R$ ${i(e.maxDiscountValue)} de desconto`),e.applicableCategories&&a.push(`V\xe1lido para: ${e.applicableCategories}`),c="\n⚠️ <b>Regras:</b>\n- "+a.join("\n- ")}let n=`
🔥 <b>NOVO CUPOM ${p.toUpperCase()}!</b>

🎟️ <b>${e.discount}</b>
🏷️ C\xf3digo: <code>${e.code}</code>
${e.description&&"CUPOM"!==e.description?`
📝 ${e.description}
`:""}${c}

🔗 <b>Resgate aqui:</b> ${r}
  `.trim();if(s)try{await (0,o.sendTelegramMessage)(s,n),console.log(`[Socials] Cupom ${e.code} enviado para o Telegram`)}catch(e){console.error("[Socials] Erro ao enviar cupom para Telegram:",e)}if(t?.value&&l?.value)try{let a=n.replace(/<b>(.*?)<\/b>/g,"*$1*").replace(/<code>(.*?)<\/code>/g,"`$1`").replace(/<i>(.*?)<\/i>/g,"_$1_");await fetch(t.value,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:a,token:l.value})}),console.log(`[Socials] Cupom ${e.code} enviado para o WhatsApp`)}catch(e){console.error("[Socials] Erro ao enviar cupom para WhatsApp:",e)}}e.s(["publishCouponToSocials",0,r])}];

//# sourceMappingURL=src_lib_socials_ts_0e2p.sn._.js.map