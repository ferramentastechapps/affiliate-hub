module.exports=[24318,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_config_test_telegram_route_actions_0e233wr.js.map