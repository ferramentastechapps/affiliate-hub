module.exports=[30221,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_whatsapp_logs_route_actions_0bgxt3i.js.map