module.exports=[16962,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_bot_status_route_actions_08s5-x2.js.map