module.exports=[24100,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_whatsapp_page_actions_0chzp5d.js.map