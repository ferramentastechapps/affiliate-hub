module.exports=[43637,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_cupons_page_actions_0owbmqe.js.map