module.exports=[87886,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_social-studio_page_actions_0ja~iv~.js.map