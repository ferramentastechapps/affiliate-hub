module.exports=[97188,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_admin_queues_page_actions_0zz_ucy.js.map