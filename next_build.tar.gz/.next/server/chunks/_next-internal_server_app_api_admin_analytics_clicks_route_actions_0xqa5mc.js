module.exports=[68894,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_analytics_clicks_route_actions_0xqa5mc.js.map