module.exports=[29585,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_webhook_products_%5Bid%5D_route_actions_13ay8-j.js.map