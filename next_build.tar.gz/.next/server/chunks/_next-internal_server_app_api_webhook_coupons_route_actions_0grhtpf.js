module.exports=[10943,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_webhook_coupons_route_actions_0grhtpf.js.map