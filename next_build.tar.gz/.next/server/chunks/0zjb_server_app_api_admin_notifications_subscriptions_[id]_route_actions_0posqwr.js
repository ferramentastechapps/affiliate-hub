module.exports=[96250,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_admin_notifications_subscriptions_%5Bid%5D_route_actions_0posqwr.js.map