module.exports=[13862,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_queues_move_route_actions_0.1_k91.js.map