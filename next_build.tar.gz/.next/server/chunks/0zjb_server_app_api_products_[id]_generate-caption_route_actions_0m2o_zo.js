module.exports=[18067,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_products_%5Bid%5D_generate-caption_route_actions_0m2o_zo.js.map