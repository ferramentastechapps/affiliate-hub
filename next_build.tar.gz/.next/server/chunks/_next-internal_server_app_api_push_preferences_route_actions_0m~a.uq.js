module.exports=[8565,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_push_preferences_route_actions_0m~a.uq.js.map