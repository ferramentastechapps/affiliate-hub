module.exports=[61500,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_products_%5Bid%5D_vote_route_actions_0a0p5yj.js.map