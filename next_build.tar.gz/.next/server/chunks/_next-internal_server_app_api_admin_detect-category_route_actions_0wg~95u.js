module.exports=[18437,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_detect-category_route_actions_0wg~95u.js.map