module.exports=[51516,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_products_%5Bid%5D_price-history_route_actions_0-krmdf.js.map