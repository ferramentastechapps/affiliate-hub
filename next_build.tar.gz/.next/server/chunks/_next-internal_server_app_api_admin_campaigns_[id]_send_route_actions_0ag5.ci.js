module.exports=[64006,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_campaigns_%5Bid%5D_send_route_actions_0ag5.ci.js.map