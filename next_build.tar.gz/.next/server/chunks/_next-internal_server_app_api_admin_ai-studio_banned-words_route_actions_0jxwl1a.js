module.exports=[30882,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_ai-studio_banned-words_route_actions_0jxwl1a.js.map