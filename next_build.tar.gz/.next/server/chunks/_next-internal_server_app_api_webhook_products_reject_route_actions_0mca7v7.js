module.exports=[86801,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_webhook_products_reject_route_actions_0mca7v7.js.map