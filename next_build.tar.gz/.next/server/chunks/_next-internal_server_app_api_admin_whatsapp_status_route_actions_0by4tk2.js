module.exports=[91395,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_whatsapp_status_route_actions_0by4tk2.js.map