module.exports=[620,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_admin_ai-studio_captions_%5Bid%5D_example_route_actions_07xs3g3.js.map