module.exports=[12823,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_products_scraped_route_actions_0uw2t~d.js.map