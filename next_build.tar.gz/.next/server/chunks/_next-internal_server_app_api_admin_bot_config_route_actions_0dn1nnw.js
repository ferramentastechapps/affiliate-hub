module.exports=[99852,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_bot_config_route_actions_0dn1nnw.js.map