module.exports=[70527,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_products_%5Bid%5D_similar_route_actions_0hhf1q_.js.map