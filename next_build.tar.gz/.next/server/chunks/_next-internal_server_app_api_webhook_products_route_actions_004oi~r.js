module.exports=[9537,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_webhook_products_route_actions_004oi~r.js.map