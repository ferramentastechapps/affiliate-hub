module.exports=[78013,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_push_history_route_actions_00o5_cm.js.map