module.exports=[89657,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_products_%5Bid%5D_images_%5BimgId%5D_route_actions_0aehkut.js.map