module.exports=[53834,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_go_%5Bid%5D_route_actions_12u.if-.js.map