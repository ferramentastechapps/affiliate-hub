module.exports=[72071,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_admin_ai-studio_preview-prompt_route_actions_0ix2na8.js.map