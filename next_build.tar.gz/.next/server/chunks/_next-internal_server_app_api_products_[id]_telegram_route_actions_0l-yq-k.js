module.exports=[11425,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_products_%5Bid%5D_telegram_route_actions_0l-yq-k.js.map