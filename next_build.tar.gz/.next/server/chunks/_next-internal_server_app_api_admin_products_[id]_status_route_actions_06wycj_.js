module.exports=[80099,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_products_%5Bid%5D_status_route_actions_06wycj_.js.map