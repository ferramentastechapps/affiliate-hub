module.exports=[61120,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_queues_lifestyle-photo_route_actions_09~gsc..js.map