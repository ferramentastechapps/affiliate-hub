module.exports=[66479,(e,o,d)=>{}];

//# sourceMappingURL=0zjb_server_app_api_admin_ai-studio_banned-words_%5Bid%5D_route_actions_0b~ofy..js.map