module.exports=[50574,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_whatsapp_action_route_actions_04lu.73.js.map